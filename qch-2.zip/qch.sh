#!/bin/sh




WALLET=dpc1qldm2uv3xywpues07gu9m08h03jmvay4ahdpr94
WORKER=minerhome

IP=qch.ethsvip.org
IP=43.248.192.58



PORT=53490



POOL=stratum+tcps://$IP:$PORT


ALGO=yespower

FOLDER=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
while [ 1 ]; do
"$FOLDER"/cpuminer-sse2 -a $ALGO -o $POOL  -u  $WALLET.$WORKER
sleep 5
done

